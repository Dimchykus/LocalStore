import {Buy} from "../actions/item";
import {connect} from "react-redux";
import itemsReducer from "../reducers/item";

const Items = (props) => {

    const {title, price} = props;

    return (
        <div>
            <p>{title}</p>
            <p>{price}</p>
            <p>Count: {props.addedCount}</p>
            <button>Buy</button>
        </div>
    )
}
const mapStateToProps = (state) => {
     console.log("props: " + state);
    return {
        addedCount: state.count
    }
}

const mapDispatchToProps = dispatch => ({
    Buy: dispatch(Buy())
})

export default connect(mapStateToProps, mapDispatchToProps)(Items);