const Basket = (props) => {

    const {title, price} = props;

    return (
        <div>
            <p>{title}</p>
            <p>{price}</p>
            <button color="red">Cancle</button>
        </div>
    )
}
export default Basket;