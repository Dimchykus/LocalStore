import React from "react"
import Items from "./items"
import Basket from "./basket"
import {connect} from "react-redux";
import {setItems} from "./../actions/item"
import axios from "axios";
import {bindActionCreators} from 'redux';
import itemsReducer from "../reducers/item";

class App extends React.Component {

    componentWillMount() {
        const {setItems} = this.props;
        axios.get('/products.json').then(({data}) => {
            setItems(data);
        })
    }

    render() {
        const {products} = this.props;
        const items = products.map(product => <Items {...product}/>);
        return (
            <div className="App">
                <div>
                    {items}
                </div>
                <div>
                    <Basket/>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        products: state.MyReducer.items
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({
        setItems: setItems,
    }, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
