const initialState = {
    items: []
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case  "SET_ITEMS":
            return{
                ...state,
                items: action.payload
            };
        case  "BUY_ITEMS":
            return{
                ...state,
                count: state.count - 1
            };
        default:
            return state;
    }
}
export default reducer;
