import { combineReducers } from 'redux';
import reducer from './item';

export default combineReducers({
    MyReducer: reducer,

});
