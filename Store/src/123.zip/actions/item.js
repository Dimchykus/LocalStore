export const Buy = () => (
    {
        type:"BUY_ITEMS"
    }
)
export const setItems = (items) => (
    {
        type:"SET_ITEMS",
        payload:items
    }
)